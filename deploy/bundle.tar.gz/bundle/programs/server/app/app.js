var require = meteorInstall({"server":{"imports":{"publications":{"images.js":["meteor/meteor","../../../both/collections/images.collection",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/imports/publications/images.js                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_1 = require('meteor/meteor');                                                                   // 1
var images_collection_1 = require('../../../both/collections/images.collection');                          // 2
meteor_1.Meteor.publish('thumbs', function (ids) {                                                         // 4
    return images_collection_1.Thumbs.collection.find({                                                    //
        originalStore: 'images',                                                                           //
        originalId: {                                                                                      //
            $in: ids                                                                                       //
        }                                                                                                  //
    });                                                                                                    //
});                                                                                                        // 11
meteor_1.Meteor.publish('images', function () {                                                            // 13
    return images_collection_1.Images.collection.find({});                                                 //
});                                                                                                        // 15
//# sourceMappingURL=images.js.map                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.js":["meteor/meteor","../../../both/collections/routes.collection",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/imports/publications/routes.js                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_1 = require('meteor/meteor');                                                                   // 1
var routes_collection_1 = require('../../../both/collections/routes.collection');                          // 2
meteor_1.Meteor.publish('routes', function () {                                                            // 5
    if (this.userId) {                                                                                     //
        return routes_collection_1.Routes.find({}, { sort: { 'sorting_date': -1 } });                      //
    }                                                                                                      //
    else {                                                                                                 //
        return routes_collection_1.Routes.find({ published: true }, {                                      //
            fields: {                                                                                      //
                'title': 1,                                                                                //
                'short_description': 1,                                                                    //
                'duration': 1,                                                                             //
                'distance': 1,                                                                             //
                'access_by_train': 1,                                                                      //
                'images': 1,                                                                               //
                'main_image_id': 1,                                                                        //
                'main_icon': 1,                                                                            //
                'url': 1,                                                                                  //
                'coordinates': 1,                                                                          //
                'zoom': 1,                                                                                 //
                'center_lat': 1,                                                                           //
                'center_lng': 1,                                                                           //
                'atractions': 1,                                                                           //
                'travel_date': 1,                                                                          //
                'sorting_date': 1,                                                                         //
                'published': 1                                                                             //
            },                                                                                             //
            sort: {                                                                                        //
                'sorting_date': -1                                                                         //
            }                                                                                              //
        });                                                                                                //
    }                                                                                                      //
});                                                                                                        // 37
meteor_1.Meteor.publish('oneRoute', function (id) {                                                        // 39
    if (this.userId) {                                                                                     //
        return routes_collection_1.Routes.find({ _id: id });                                               //
    }                                                                                                      //
    else {                                                                                                 //
        return routes_collection_1.Routes.find({ _id: id, published: true });                              //
    }                                                                                                      //
});                                                                                                        // 45
meteor_1.Meteor.publish('oneRouteByUrl', function (url) {                                                  // 47
    if (this.userId) {                                                                                     //
        return routes_collection_1.Routes.find({ url: url });                                              //
    }                                                                                                      //
    else {                                                                                                 //
        return routes_collection_1.Routes.find({ url: url, published: true });                             //
    }                                                                                                      //
});                                                                                                        // 53
meteor_1.Meteor.publish('latestRoute', function (url) {                                                    // 55
    return routes_collection_1.Routes.find({ published: true }, { sort: {                                  //
            'sorting_date': -1                                                                             //
        }, limit: 1 });                                                                                    //
});                                                                                                        // 59
meteor_1.Meteor.publish('searchRoutes', function (searchValue) {                                           // 61
    if (!searchValue) {                                                                                    //
        return routes_collection_1.Routes.find({                                                           //
            $and: [{}, false]                                                                              //
        });                                                                                                //
    }                                                                                                      //
    return routes_collection_1.Routes.find({ $text: { $search: searchValue }, published: true }, {         //
        fields: {                                                                                          //
            score: { $meta: "textScore" }                                                                  //
        },                                                                                                 //
        sort: {                                                                                            //
            score: { $meta: "textScore" }                                                                  //
        },                                                                                                 //
        limit: 10                                                                                          //
    });                                                                                                    //
});                                                                                                        // 80
meteor_1.Meteor.publish('routeMapDetails', function (id) {                                                 // 82
    if (this.userId) {                                                                                     //
        return routes_collection_1.Routes.find({ _id: id });                                               //
    }                                                                                                      //
    else {                                                                                                 //
        return routes_collection_1.Routes.find({ _id: id, published: true }, { fields: { 'coordinates': 1, 'zoom': 1, 'center_lat': 1, 'center_lng': 1 } });
    }                                                                                                      //
});                                                                                                        // 89
//# sourceMappingURL=routes.js.map                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/imports/publications/users.js                                                                    //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
//# sourceMappingURL=users.js.map                                                                          //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"main.js":["meteor/meteor","meteor/accounts-base","../both/collections/routes.collection","meteor/webapp","./imports/publications/users","./imports/publications/routes","./imports/publications/images",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/main.js                                                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_1 = require('meteor/meteor');                                                                   // 1
var accounts_base_1 = require('meteor/accounts-base');                                                     // 2
var routes_collection_1 = require('../both/collections/routes.collection');                                // 3
var webapp_1 = require('meteor/webapp');                                                                   // 4
require('./imports/publications/users');                                                                   // 6
require('./imports/publications/routes');                                                                  // 7
require('./imports/publications/images');                                                                  // 8
meteor_1.Meteor.startup(function () {                                                                      // 10
    routes_collection_1.Routes.rawCollection().createIndex({                                               //
        "title": "text",                                                                                   //
        "body": "text",                                                                                    //
        "short_description": "text",                                                                       //
        "atractions.name": "text",                                                                         //
        "atractions.description": "text"                                                                   //
    });                                                                                                    //
    if (meteor_1.Meteor.isServer) {                                                                        //
        process.env.MAIL_URL = "smtp://dviraciu.marsrutai%40gmail.com:kokiemarsrutai@smtp.gmail.com:465/";
    }                                                                                                      //
    accounts_base_1.Accounts.config({                                                                      //
        forbidClientAccountCreation: true                                                                  //
    });                                                                                                    //
    webapp_1.WebApp.addHtmlAttributeHook(function () { return ({ lang: 'lt-LT' }); });                     //
});                                                                                                        // 30
//# sourceMappingURL=main.js.map                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"both":{"collections":{"images.collection.js":["meteor-rxjs","meteor/meteor","meteor/jalik:ufs","gm",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/collections/images.collection.js                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_rxjs_1 = require('meteor-rxjs');                                                                // 1
var meteor_1 = require('meteor/meteor');                                                                   // 2
var jalik_ufs_1 = require('meteor/jalik:ufs');                                                             // 3
exports.Images = new meteor_rxjs_1.MongoObservable.Collection('images');                                   // 6
exports.Thumbs = new meteor_rxjs_1.MongoObservable.Collection('thumbs');                                   // 7
function loggedIn() {                                                                                      // 9
    return !!meteor_1.Meteor.user();                                                                       //
}                                                                                                          // 11
exports.ThumbsStore = new jalik_ufs_1.UploadFS.store.GridFS({                                              // 13
    collection: exports.Thumbs.collection,                                                                 //
    name: 'thumbs',                                                                                        //
    permissions: new jalik_ufs_1.UploadFS.StorePermissions({                                               //
        insert: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        },                                                                                                 //
        update: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        },                                                                                                 //
        remove: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        }                                                                                                  //
    }),                                                                                                    //
    transformWrite: function (from, to, fileId, file) {                                                    //
        // Resize to 32x32                                                                                 //
        var gm = require('gm');                                                                            //
        gm(from, file.name)                                                                                //
            .resize(32, 32)                                                                                //
            .gravity('Center')                                                                             //
            .extent(32, 32)                                                                                //
            .quality(75)                                                                                   //
            .stream()                                                                                      //
            .pipe(to);                                                                                     //
    }                                                                                                      //
});                                                                                                        //
exports.ImagesStore = new jalik_ufs_1.UploadFS.store.GridFS({                                              // 41
    collection: exports.Images.collection,                                                                 //
    name: 'images',                                                                                        //
    filter: new jalik_ufs_1.UploadFS.Filter({                                                              //
        contentTypes: ['image/*']                                                                          //
    }),                                                                                                    //
    copyTo: [                                                                                              //
        exports.ThumbsStore                                                                                //
    ],                                                                                                     //
    permissions: new jalik_ufs_1.UploadFS.StorePermissions({                                               //
        insert: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        },                                                                                                 //
        update: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        },                                                                                                 //
        remove: function (userId, doc) {                                                                   //
            return loggedIn();                                                                             //
        }                                                                                                  //
    })                                                                                                     //
});                                                                                                        //
exports.Images.allow({                                                                                     // 65
    insert: loggedIn,                                                                                      //
    update: loggedIn,                                                                                      //
    remove: loggedIn                                                                                       //
});                                                                                                        //
exports.Thumbs.allow({                                                                                     // 71
    insert: loggedIn,                                                                                      //
    update: loggedIn,                                                                                      //
    remove: loggedIn                                                                                       //
});                                                                                                        //
//# sourceMappingURL=images.collection.js.map                                                              //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.collection.js":["meteor-rxjs","meteor/meteor",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/collections/routes.collection.js                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_rxjs_1 = require('meteor-rxjs');                                                                // 1
var meteor_1 = require('meteor/meteor');                                                                   // 2
exports.Routes = new meteor_rxjs_1.MongoObservable.Collection('routes');                                   // 6
function loggedIn() {                                                                                      // 9
    return !!meteor_1.Meteor.user();                                                                       //
}                                                                                                          // 11
exports.Routes.allow({                                                                                     // 13
    insert: loggedIn,                                                                                      //
    update: loggedIn,                                                                                      //
    remove: loggedIn                                                                                       //
});                                                                                                        //
//# sourceMappingURL=routes.collection.js.map                                                              //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.collection.js":["meteor-rxjs","meteor/meteor",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/collections/users.collection.js                                                                    //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var meteor_rxjs_1 = require('meteor-rxjs');                                                                // 1
var meteor_1 = require('meteor/meteor');                                                                   // 2
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);                         // 4
//# sourceMappingURL=users.collection.js.map                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods":{"images.methods.js":["meteor/jalik:ufs","../collections/images.collection",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/methods/images.methods.js                                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var jalik_ufs_1 = require('meteor/jalik:ufs');                                                             // 1
var images_collection_1 = require('../collections/images.collection');                                     // 2
function upload(data) {                                                                                    // 4
    return new Promise(function (resolve, reject) {                                                        //
        // pick from an object only: name, type and size                                                   //
        var file = {                                                                                       //
            name: data.name,                                                                               //
            type: data.type,                                                                               //
            size: data.size,                                                                               //
        };                                                                                                 //
        var upload = new jalik_ufs_1.UploadFS.Uploader({                                                   //
            data: data,                                                                                    //
            file: file,                                                                                    //
            store: images_collection_1.ImagesStore,                                                        //
            onError: reject,                                                                               //
            onComplete: resolve                                                                            //
        });                                                                                                //
        upload.start();                                                                                    //
    });                                                                                                    //
}                                                                                                          // 23
exports.upload = upload;                                                                                   // 4
function remove(id) {                                                                                      // 25
    images_collection_1.ThumbsStore.getCollection().remove({ _id: id });                                   //
    images_collection_1.ImagesStore.getCollection().remove({ _id: id });                                   //
}                                                                                                          // 28
exports.remove = remove;                                                                                   // 25
//# sourceMappingURL=images.methods.js.map                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.methods.js":["meteor/email","meteor/check","meteor/meteor","meteor/http",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/methods/routes.methods.js                                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var email_1 = require('meteor/email');                                                                     // 2
var check_1 = require('meteor/check');                                                                     // 3
var meteor_1 = require('meteor/meteor');                                                                   // 4
var http_1 = require('meteor/http');                                                                       // 5
meteor_1.Meteor.methods({                                                                                  // 7
    contactAutors: function (contact, recapcha) {                                                          //
        this.unblock();                                                                                    //
        check_1.check(recapcha, String);                                                                   //
        check_1.check(contact.email, String);                                                              //
        check_1.check(contact.message, String);                                                            //
        if (meteor_1.Meteor.isServer) {                                                                    //
            try {                                                                                          //
                var result = http_1.HTTP.post('https://www.google.com/recaptcha/api/siteverify', {         //
                    params: {                                                                              //
                        secret: '6Lc0PyAUAAAAAPEf7lb3-Ch-vnG83PY6Li5AgOxq',                                //
                        response: recapcha                                                                 //
                    }                                                                                      //
                });                                                                                        //
                if (result.statusCode = 200 && result.data.success) {                                      //
                    email_1.Email.send({                                                                   //
                        from: contact.email,                                                               //
                        to: 'dviraciu.marsrutai@gmail.com',                                                //
                        replyTo: contact.email || undefined,                                               //
                        subject: 'DM KLAUSIMAS NUO: ' + contact.email,                                     //
                        text: "" + contact.message                                                         //
                    });                                                                                    //
                }                                                                                          //
                else {                                                                                     //
                    throw new meteor_1.Meteor.Error('recapcha', "fail");                                   //
                }                                                                                          //
            }                                                                                              //
            catch (e) {                                                                                    //
                throw new meteor_1.Meteor.Error('http', "fail");                                           //
            }                                                                                              //
        }                                                                                                  //
    }                                                                                                      //
});                                                                                                        //
//# sourceMappingURL=routes.methods.js.map                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"models":{"collection-object.model.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/models/collection-object.model.js                                                                  //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
//# sourceMappingURL=collection-object.model.js.map                                                        //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"image.model.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/models/image.model.js                                                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
//# sourceMappingURL=image.model.js.map                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"route.model.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/models/route.model.js                                                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
//# sourceMappingURL=route.model.js.map                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.model.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// both/models/user.model.js                                                                               //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
//# sourceMappingURL=user.model.js.map                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{"extensions":[".js",".json",".ts",".html",".less",".scss"]});
require("./both/collections/images.collection.js");
require("./both/collections/routes.collection.js");
require("./both/collections/users.collection.js");
require("./both/methods/images.methods.js");
require("./both/methods/routes.methods.js");
require("./both/models/collection-object.model.js");
require("./both/models/image.model.js");
require("./both/models/route.model.js");
require("./both/models/user.model.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
