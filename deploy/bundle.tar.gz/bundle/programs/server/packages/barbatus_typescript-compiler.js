(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Logger, FileMixin, TypeScriptCompiler, TypeScript;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:typescript-compiler":{"logger.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/createClass",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/logger.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _createClass;module.import('babel-runtime/helpers/createClass',{"default":function(v){_createClass=v}});
                                                                                                                      //
var util = Npm.require('util');                                                                                       // 1
                                                                                                                      //
var Logger_ = function () {                                                                                           //
  function Logger_() {                                                                                                // 4
    _classCallCheck(this, Logger_);                                                                                   // 4
                                                                                                                      //
    this.llevel = process.env.TYPESCRIPT_LOG;                                                                         // 5
  }                                                                                                                   // 6
                                                                                                                      //
  Logger_.prototype.newProfiler = function () {                                                                       //
    function newProfiler(name) {                                                                                      //
      var profiler = new Profiler(name);                                                                              // 9
      if (this.isProfile) profiler.start();                                                                           // 10
      return profiler;                                                                                                // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return newProfiler;                                                                                               //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.log = function () {                                                                               //
    function log(msg) {                                                                                               //
      if (this.llevel >= 1) {                                                                                         // 27
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {     // 27
          args[_key - 1] = arguments[_key];                                                                           // 26
        }                                                                                                             // 27
                                                                                                                      //
        console.log.apply(null, [msg].concat(args));                                                                  // 28
      }                                                                                                               // 29
    }                                                                                                                 // 30
                                                                                                                      //
    return log;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.debug = function () {                                                                             //
    function debug(msg) {                                                                                             //
      if (this.isDebug) {                                                                                             // 33
        for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];                                                                         // 32
        }                                                                                                             // 33
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 34
      }                                                                                                               // 35
    }                                                                                                                 // 36
                                                                                                                      //
    return debug;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.assert = function () {                                                                            //
    function assert(msg) {                                                                                            //
      if (this.isAssert) {                                                                                            // 39
        for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
          args[_key3 - 1] = arguments[_key3];                                                                         // 38
        }                                                                                                             // 39
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 40
      }                                                                                                               // 41
    }                                                                                                                 // 42
                                                                                                                      //
    return assert;                                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  _createClass(Logger_, [{                                                                                            //
    key: 'isDebug',                                                                                                   //
    get: function () {                                                                                                //
      function get() {                                                                                                //
        return this.llevel >= 2;                                                                                      // 15
      }                                                                                                               // 16
                                                                                                                      //
      return get;                                                                                                     //
    }()                                                                                                               //
  }, {                                                                                                                //
    key: 'isProfile',                                                                                                 //
    get: function () {                                                                                                //
      function get() {                                                                                                //
        return this.llevel >= 3;                                                                                      // 19
      }                                                                                                               // 20
                                                                                                                      //
      return get;                                                                                                     //
    }()                                                                                                               //
  }, {                                                                                                                //
    key: 'isAssert',                                                                                                  //
    get: function () {                                                                                                //
      function get() {                                                                                                //
        return this.llevel >= 4;                                                                                      // 23
      }                                                                                                               // 24
                                                                                                                      //
      return get;                                                                                                     //
    }()                                                                                                               //
  }]);                                                                                                                //
                                                                                                                      //
  return Logger_;                                                                                                     //
}();                                                                                                                  //
                                                                                                                      //
;                                                                                                                     // 43
                                                                                                                      //
Logger = new Logger_();                                                                                               // 45
                                                                                                                      //
var Profiler = function () {                                                                                          //
  function Profiler(name) {                                                                                           // 48
    _classCallCheck(this, Profiler);                                                                                  // 48
                                                                                                                      //
    this.name = name;                                                                                                 // 49
  }                                                                                                                   // 50
                                                                                                                      //
  Profiler.prototype.start = function () {                                                                            //
    function start() {                                                                                                //
      console.log('%s started', this.name);                                                                           // 53
      console.time(util.format('%s time', this.name));                                                                // 54
      this._started = true;                                                                                           // 55
    }                                                                                                                 // 56
                                                                                                                      //
    return start;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Profiler.prototype.end = function () {                                                                              //
    function end() {                                                                                                  //
      if (this._started) {                                                                                            // 59
        console.timeEnd(util.format('%s time', this.name));                                                           // 60
      }                                                                                                               // 61
    }                                                                                                                 // 62
                                                                                                                      //
    return end;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  return Profiler;                                                                                                    //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"file-mixin.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/file-mixin.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
FileMixin = {                                                                                                         // 2
  getShortArch: function () {                                                                                         // 3
    function getShortArch() {                                                                                         // 2
      var arch = this.getArch();                                                                                      // 4
      return (/^web/.test(arch) ? 'web' : 'os'                                                                        // 5
      );                                                                                                              // 5
    }                                                                                                                 // 6
                                                                                                                      //
    return getShortArch;                                                                                              // 2
  }(),                                                                                                                // 2
  warn: function () {                                                                                                 // 8
    function warn(error) {                                                                                            // 2
      console.log(error.sourcePath + ' (' + error.line + ', ' + error.column + '): ' + error.message);                // 9
    }                                                                                                                 // 10
                                                                                                                      //
    return warn;                                                                                                      // 2
  }(),                                                                                                                // 2
  isBare: function () {                                                                                               // 12
    function isBare() {                                                                                               // 2
      var fileOptions = this.getFileOptions();                                                                        // 13
      return fileOptions && fileOptions.bare;                                                                         // 14
    }                                                                                                                 // 15
                                                                                                                      //
    return isBare;                                                                                                    // 2
  }(),                                                                                                                // 2
                                                                                                                      //
                                                                                                                      //
  // Get root app config.                                                                                             // 17
  isMainConfig: function () {                                                                                         // 18
    function isMainConfig() {                                                                                         // 2
      var filePath = this.getPathInPackage();                                                                         // 19
      return (/^tsconfig\.json$/.test(filePath)                                                                       // 20
      );                                                                                                              // 20
    }                                                                                                                 // 21
                                                                                                                      //
    return isMainConfig;                                                                                              // 2
  }(),                                                                                                                // 2
  isConfig: function () {                                                                                             // 23
    function isConfig() {                                                                                             // 2
      var filePath = this.getPathInPackage();                                                                         // 24
      return (/tsconfig\.json$/.test(filePath)                                                                        // 25
      );                                                                                                              // 25
    }                                                                                                                 // 26
                                                                                                                      //
    return isConfig;                                                                                                  // 2
  }(),                                                                                                                // 2
  isServerConfig: function () {                                                                                       // 28
    function isServerConfig() {                                                                                       // 2
      var filePath = this.getPathInPackage();                                                                         // 29
      return (/^server\/tsconfig\.json$/.test(filePath)                                                               // 30
      );                                                                                                              // 30
    }                                                                                                                 // 31
                                                                                                                      //
    return isServerConfig;                                                                                            // 2
  }(),                                                                                                                // 2
  isDeclaration: function () {                                                                                        // 33
    function isDeclaration() {                                                                                        // 2
      return TypeScript.isDeclarationFile(this.getBasename());                                                        // 34
    }                                                                                                                 // 35
                                                                                                                      //
    return isDeclaration;                                                                                             // 2
  }(),                                                                                                                // 2
                                                                                                                      //
                                                                                                                      //
  // Get path with package prefix if any.                                                                             // 37
  getPackagePrefixPath: function () {                                                                                 // 38
    function getPackagePrefixPath() {                                                                                 // 2
      var packageName = this.getPackageName();                                                                        // 39
      packageName = packageName ? packageName.replace(':', '_') + '/' : '';                                           // 40
      var inputFilePath = this.getPathInPackage();                                                                    // 42
      return packageName + inputFilePath;                                                                             // 43
    }                                                                                                                 // 44
                                                                                                                      //
    return getPackagePrefixPath;                                                                                      // 2
  }(),                                                                                                                // 2
  getES6ModuleName: function () {                                                                                     // 46
    function getES6ModuleName() {                                                                                     // 2
      var packaged = this.getPackagePrefixPath();                                                                     // 47
      return TypeScript.removeTsExt(packaged);                                                                        // 48
    }                                                                                                                 // 49
                                                                                                                      //
    return getES6ModuleName;                                                                                          // 2
  }()                                                                                                                 // 2
};                                                                                                                    // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript-compiler.js":["babel-runtime/helpers/classCallCheck",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript-compiler.js                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});
var async = Npm.require('async');                                                                                     // 1
var path = Npm.require('path');                                                                                       // 2
var Future = Npm.require('fibers/future');                                                                            // 3
                                                                                                                      //
var _Npm$require = Npm.require('meteor-typescript');                                                                  //
                                                                                                                      //
var TSBuild = _Npm$require.TSBuild;                                                                                   //
var validateTsConfig = _Npm$require.validateTsConfig;                                                                 //
var getExcludeRegExp = _Npm$require.getExcludeRegExp;                                                                 //
                                                                                                                      //
var _Npm$require2 = Npm.require('crypto');                                                                            //
                                                                                                                      //
var createHash = _Npm$require2.createHash;                                                                            //
                                                                                                                      //
// Default exclude paths.                                                                                             // 13
                                                                                                                      //
var defExclude = ['node_modules/**'];                                                                                 // 14
                                                                                                                      //
// Paths to exclude when compiling for the server.                                                                    // 16
var exlWebRegExp = new RegExp(getExcludeRegExp(['typings/main/**', 'typings/main.d.ts']));                            // 17
                                                                                                                      //
// Paths to exclude when compiling for the client.                                                                    // 20
var exlMainRegExp = new RegExp(getExcludeRegExp(['typings/browser/**', 'typings/browser.d.ts']));                     // 21
                                                                                                                      //
TypeScriptCompiler = function () {                                                                                    // 24
  function TypeScriptCompiler(extraOptions, maxParallelism) {                                                         // 25
    _classCallCheck(this, TypeScriptCompiler);                                                                        // 25
                                                                                                                      //
    TypeScript.validateExtraOptions(extraOptions);                                                                    // 26
                                                                                                                      //
    this.extraOptions = extraOptions;                                                                                 // 28
    this.maxParallelism = maxParallelism || 10;                                                                       // 29
    this.serverOptions = null;                                                                                        // 30
    this.tsconfig = TypeScript.getDefaultOptions();                                                                   // 31
    this.tsconfig.exclude = new RegExp(getExcludeRegExp(defExclude));                                                 // 32
    this.cfgHash = null;                                                                                              // 34
    this.diagHash = new Set();                                                                                        // 35
    this.archSet = new Set();                                                                                         // 36
  }                                                                                                                   // 37
                                                                                                                      //
  TypeScriptCompiler.prototype.processFilesForTarget = function () {                                                  // 24
    function processFilesForTarget(inputFiles) {                                                                      // 24
      var _this = this;                                                                                               // 39
                                                                                                                      //
      this.extendFiles(inputFiles);                                                                                   // 40
                                                                                                                      //
      // Exclude by default.                                                                                          // 42
      inputFiles = this.excludeFiles(inputFiles);                                                                     // 43
                                                                                                                      //
      Logger.log('input files: %s', inputFiles.map(function (inputFile) {                                             // 45
        return inputFile.getPathInPackage();                                                                          // 46
      }));                                                                                                            // 46
                                                                                                                      //
      // If tsconfig.json has changed, create new one.                                                                // 48
      this.processConfig(inputFiles);                                                                                 // 49
                                                                                                                      //
      // Exclude by tsconfig.                                                                                         // 51
      inputFiles = this.excludeFiles(inputFiles);                                                                     // 52
                                                                                                                      //
      if (!inputFiles.length) return;                                                                                 // 54
                                                                                                                      //
      var filesMap = new Map();                                                                                       // 56
      inputFiles.forEach(function (inputFile, index) {                                                                // 57
        filesMap.set(_this.getExtendedPath(inputFile), index);                                                        // 58
      });                                                                                                             // 59
                                                                                                                      //
      var getFileContent = function () {                                                                              // 61
        function getFileContent(filePath) {                                                                           // 61
          var index = filesMap.get(filePath);                                                                         // 62
          if (index === undefined) {                                                                                  // 63
            var filePathNoRootSlash = filePath.replace(/^\//, '');                                                    // 64
            index = filesMap.get(filePathNoRootSlash);                                                                // 65
          }                                                                                                           // 66
          return index !== undefined ? inputFiles[index].getContentsAsString() : null;                                // 67
        }                                                                                                             // 69
                                                                                                                      //
        return getFileContent;                                                                                        // 61
      }();                                                                                                            // 61
                                                                                                                      //
      // Assemble options.                                                                                            // 71
      var arch = inputFiles[0].getArch();                                                                             // 72
      var _tsconfig = this.tsconfig;                                                                                  // 39
      var _tsconfig$compilerOpt = _tsconfig.compilerOptions;                                                          // 39
      var compilerOptions = _tsconfig$compilerOpt === undefined ? {} : _tsconfig$compilerOpt;                         // 39
      var typings = _tsconfig.typings;                                                                                // 39
      var useCache = _tsconfig.useCache;                                                                              // 39
                                                                                                                      //
      if (!/^web/.test(arch) && this.serverOptions) {                                                                 // 74
        Object.assign(compilerOptions, this.serverOptions);                                                           // 75
      }                                                                                                               // 76
      // Apply extra options.                                                                                         // 77
      if (this.extraOptions) {                                                                                        // 78
        Object.assign(compilerOptions, this.extraOptions);                                                            // 79
      }                                                                                                               // 80
                                                                                                                      //
      var buildOptions = { compilerOptions: compilerOptions, typings: typings, useCache: useCache };                  // 82
      Logger.log('compiler options: %j', compilerOptions);                                                            // 83
                                                                                                                      //
      var pcompile = Logger.newProfiler('compilation');                                                               // 85
      var archFiles = this.filterArchFiles(inputFiles, arch);                                                         // 86
      var filePaths = archFiles.map(function (inputFile) {                                                            // 87
        return _this.getExtendedPath(inputFile);                                                                      // 87
      });                                                                                                             // 87
      Logger.log('process files: %s', filePaths);                                                                     // 88
      buildOptions.arch = arch;                                                                                       // 89
      var pbuild = Logger.newProfiler('tsBuild');                                                                     // 90
      var tsBuild = new TSBuild(filePaths, getFileContent, buildOptions);                                             // 91
      pbuild.end();                                                                                                   // 92
                                                                                                                      //
      var pfiles = Logger.newProfiler('tsEmitFiles');                                                                 // 94
      var future = new Future();                                                                                      // 95
      // Don't emit typings.                                                                                          // 96
      archFiles = archFiles.filter(function (inputFile) {                                                             // 97
        return !inputFile.isDeclaration();                                                                            // 97
      });                                                                                                             // 97
      async.eachLimit(archFiles, this.maxParallelism, function (inputFile, cb) {                                      // 98
        var co = compilerOptions;                                                                                     // 99
        var source = inputFile.getContentsAsString();                                                                 // 100
        var inputFilePath = inputFile.getPathInPackage();                                                             // 101
        var outputFilePath = TypeScript.removeTsExt(inputFilePath) + '.js';                                           // 102
        var toBeAdded = {                                                                                             // 103
          sourcePath: inputFilePath,                                                                                  // 104
          path: outputFilePath,                                                                                       // 105
          data: source,                                                                                               // 106
          hash: inputFile.getSourceHash(),                                                                            // 107
          sourceMap: null,                                                                                            // 108
          bare: inputFile.isBare()                                                                                    // 109
        };                                                                                                            // 103
                                                                                                                      //
        var filePath = _this.getExtendedPath(inputFile);                                                              // 112
        var moduleName = _this.getFileModuleName(inputFile, co);                                                      // 113
                                                                                                                      //
        var pemit = Logger.newProfiler('tsEmit');                                                                     // 115
        var result = tsBuild.emit(filePath, moduleName);                                                              // 116
        var throwSyntax = _this.processDiagnostics(inputFile, result.diagnostics, co);                                // 117
        pemit.end();                                                                                                  // 119
                                                                                                                      //
        if (!throwSyntax) {                                                                                           // 121
          toBeAdded.data = result.code;                                                                               // 122
          var module = compilerOptions.module;                                                                        // 123
          toBeAdded.bare = toBeAdded.bare || module === 'none';                                                       // 124
          toBeAdded.hash = result.hash;                                                                               // 125
          toBeAdded.sourceMap = result.sourceMap;                                                                     // 126
          inputFile.addJavaScript(toBeAdded);                                                                         // 127
        }                                                                                                             // 128
                                                                                                                      //
        cb();                                                                                                         // 130
      }, future.resolver());                                                                                          // 131
                                                                                                                      //
      pfiles.end();                                                                                                   // 133
                                                                                                                      //
      future.wait();                                                                                                  // 135
                                                                                                                      //
      pcompile.end();                                                                                                 // 137
    }                                                                                                                 // 138
                                                                                                                      //
    return processFilesForTarget;                                                                                     // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.extendFiles = function () {                                                            // 24
    function extendFiles(inputFiles, mixins) {                                                                        // 24
      mixins = _.extend({}, FileMixin, mixins);                                                                       // 141
      inputFiles.forEach(function (inputFile) {                                                                       // 142
        return _.defaults(inputFile, mixins);                                                                         // 142
      });                                                                                                             // 142
    }                                                                                                                 // 143
                                                                                                                      //
    return extendFiles;                                                                                               // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.processDiagnostics = function () {                                                     // 24
    function processDiagnostics(inputFile, diagnostics, compilerOptions) {                                            // 24
      var _this2 = this;                                                                                              // 145
                                                                                                                      //
      // Remove duplicated warnings for shared files                                                                  // 146
      // by saving hashes of already shown warnings.                                                                  // 147
      var reduce = function () {                                                                                      // 148
        function reduce(diagnostic, cb) {                                                                             // 148
          var dob = {                                                                                                 // 149
            message: diagnostic.message,                                                                              // 150
            sourcePath: _this2.getExtendedPath(inputFile),                                                            // 151
            line: diagnostic.line,                                                                                    // 152
            column: diagnostic.column                                                                                 // 153
          };                                                                                                          // 149
          var arch = inputFile.getArch();                                                                             // 155
          // TODO: find out how to get list of architectures.                                                         // 156
          _this2.archSet.add(arch);                                                                                   // 157
                                                                                                                      //
          var shown = false;                                                                                          // 159
          for (var _iterator = _this2.archSet.keys(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                                 // 160
                                                                                                                      //
            if (_isArray) {                                                                                           // 160
              if (_i >= _iterator.length) break;                                                                      // 160
              _ref = _iterator[_i++];                                                                                 // 160
            } else {                                                                                                  // 160
              _i = _iterator.next();                                                                                  // 160
              if (_i.done) break;                                                                                     // 160
              _ref = _i.value;                                                                                        // 160
            }                                                                                                         // 160
                                                                                                                      //
            var key = _ref;                                                                                           // 160
                                                                                                                      //
            if (key !== arch) {                                                                                       // 161
              dob.arch = key;                                                                                         // 162
              var _hash = _this2.getShallowHash(dob);                                                                 // 163
              if (_this2.diagHash.has(_hash)) {                                                                       // 164
                shown = true;break;                                                                                   // 165
              }                                                                                                       // 166
            }                                                                                                         // 167
          }                                                                                                           // 168
          if (!shown) {                                                                                               // 169
            dob.arch = arch;                                                                                          // 170
            var hash = _this2.getShallowHash(dob);                                                                    // 171
            _this2.diagHash.add(hash);                                                                                // 172
            cb(dob);                                                                                                  // 173
          }                                                                                                           // 174
        }                                                                                                             // 175
                                                                                                                      //
        return reduce;                                                                                                // 148
      }();                                                                                                            // 148
                                                                                                                      //
      // Always throw syntax errors.                                                                                  // 177
      var throwSyntax = !!diagnostics.syntacticErrors.length;                                                         // 178
      diagnostics.syntacticErrors.forEach(function (diagnostic) {                                                     // 179
        reduce(diagnostic, function (dob) {                                                                           // 180
          return inputFile.error(dob);                                                                                // 180
        });                                                                                                           // 180
      });                                                                                                             // 181
                                                                                                                      //
      var packageName = inputFile.getPackageName();                                                                   // 183
      if (packageName) return throwSyntax;                                                                            // 184
                                                                                                                      //
      // And log out other errors except package files.                                                               // 186
      if (compilerOptions && compilerOptions.diagnostics) {                                                           // 187
        diagnostics.semanticErrors.forEach(function (diagnostic) {                                                    // 188
          reduce(diagnostic, function (dob) {                                                                         // 189
            return inputFile.warn(dob);                                                                               // 189
          });                                                                                                         // 189
        });                                                                                                           // 190
      }                                                                                                               // 191
                                                                                                                      //
      return throwSyntax;                                                                                             // 193
    }                                                                                                                 // 194
                                                                                                                      //
    return processDiagnostics;                                                                                        // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.getShallowHash = function () {                                                         // 24
    function getShallowHash(ob) {                                                                                     // 24
      var hash = createHash('sha1');                                                                                  // 197
      var keys = Object.keys(ob);                                                                                     // 198
      keys.sort();                                                                                                    // 199
                                                                                                                      //
      keys.forEach(function (key) {                                                                                   // 201
        hash.update(key).update('' + ob[key]);                                                                        // 202
      });                                                                                                             // 203
                                                                                                                      //
      return hash.digest('hex');                                                                                      // 205
    }                                                                                                                 // 206
                                                                                                                      //
    return getShallowHash;                                                                                            // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.getExtendedPath = function () {                                                        // 24
    function getExtendedPath(inputFile) {                                                                             // 24
      var packageName = inputFile.getPackageName();                                                                   // 209
      var packagedPath = inputFile.getPackagePrefixPath();                                                            // 210
                                                                                                                      //
      var filePath = packageName ? 'packages/' + packagedPath : packagedPath;                                         // 212
                                                                                                                      //
      return filePath;                                                                                                // 215
    }                                                                                                                 // 216
                                                                                                                      //
    return getExtendedPath;                                                                                           // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.getFileModuleName = function () {                                                      // 24
    function getFileModuleName(inputFile, options) {                                                                  // 24
      if (options.module === 'none') return null;                                                                     // 219
                                                                                                                      //
      return inputFile.getES6ModuleName();                                                                            // 221
    }                                                                                                                 // 222
                                                                                                                      //
    return getFileModuleName;                                                                                         // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.processConfig = function () {                                                          // 24
    function processConfig(inputFiles) {                                                                              // 24
      for (var _iterator2 = inputFiles, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref2;                                                                                                    // 225
                                                                                                                      //
        if (_isArray2) {                                                                                              // 225
          if (_i2 >= _iterator2.length) break;                                                                        // 225
          _ref2 = _iterator2[_i2++];                                                                                  // 225
        } else {                                                                                                      // 225
          _i2 = _iterator2.next();                                                                                    // 225
          if (_i2.done) break;                                                                                        // 225
          _ref2 = _i2.value;                                                                                          // 225
        }                                                                                                             // 225
                                                                                                                      //
        var inputFile = _ref2;                                                                                        // 225
                                                                                                                      //
        // Parse root config.                                                                                         // 226
        if (inputFile.isMainConfig()) {                                                                               // 227
          var source = inputFile.getContentsAsString();                                                               // 228
          var hash = inputFile.getSourceHash();                                                                       // 229
          // If hashes differ, create new tsconfig.                                                                   // 230
          if (hash !== this.cfgHash) {                                                                                // 231
            this.tsconfig = this.parseConfig(source);                                                                 // 232
            this.cfgHash = hash;                                                                                      // 233
          }                                                                                                           // 234
        }                                                                                                             // 235
                                                                                                                      //
        // Parse server config.                                                                                       // 237
        // Take only target and lib values.                                                                           // 238
        if (inputFile.isServerConfig()) {                                                                             // 239
          var _source = inputFile.getContentsAsString();                                                              // 240
                                                                                                                      //
          var _parseConfig = this.parseConfig(_source);                                                               // 239
                                                                                                                      //
          var compilerOptions = _parseConfig.compilerOptions;                                                         // 239
                                                                                                                      //
          if (compilerOptions) {                                                                                      // 242
            var target = compilerOptions.target;                                                                      // 242
            var lib = compilerOptions.lib;                                                                            // 242
                                                                                                                      //
            this.serverOptions = { target: target, lib: lib };                                                        // 244
          }                                                                                                           // 245
        }                                                                                                             // 246
      }                                                                                                               // 247
    }                                                                                                                 // 248
                                                                                                                      //
    return processConfig;                                                                                             // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.parseConfig = function () {                                                            // 24
    function parseConfig(cfgContent) {                                                                                // 24
      var tsconfig = null;                                                                                            // 251
                                                                                                                      //
      try {                                                                                                           // 253
        tsconfig = JSON.parse(cfgContent);                                                                            // 254
                                                                                                                      //
        validateTsConfig(tsconfig);                                                                                   // 256
      } catch (err) {                                                                                                 // 257
        throw new Error('Format of the tsconfig is invalid: ' + err);                                                 // 258
      }                                                                                                               // 259
                                                                                                                      //
      var exclude = tsconfig.exclude || [];                                                                           // 261
      exclude = exclude.concat(defExclude);                                                                           // 262
                                                                                                                      //
      try {                                                                                                           // 264
        var regExp = getExcludeRegExp(exclude);                                                                       // 265
        tsconfig.exclude = regExp && new RegExp(regExp);                                                              // 266
      } catch (err) {                                                                                                 // 267
        throw new Error('Format of an exclude path is invalid: ' + err);                                              // 268
      }                                                                                                               // 269
                                                                                                                      //
      return tsconfig;                                                                                                // 271
    }                                                                                                                 // 272
                                                                                                                      //
    return parseConfig;                                                                                               // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.excludeFiles = function () {                                                           // 24
    function excludeFiles(inputFiles) {                                                                               // 24
      var _this3 = this;                                                                                              // 274
                                                                                                                      //
      var resultFiles = inputFiles;                                                                                   // 275
                                                                                                                      //
      var pexclude = Logger.newProfiler('exclude');                                                                   // 277
      if (this.tsconfig.exclude) {                                                                                    // 278
        resultFiles = resultFiles.filter(function (inputFile) {                                                       // 279
          var path = inputFile.getPathInPackage();                                                                    // 280
          // There seems to an issue with getRegularExpressionForWildcard:                                            // 281
          // result regexp always starts with /.                                                                      // 282
          return !_this3.tsconfig.exclude.test('/' + path);                                                           // 283
        });                                                                                                           // 284
      }                                                                                                               // 285
      pexclude.end();                                                                                                 // 286
                                                                                                                      //
      return resultFiles;                                                                                             // 288
    }                                                                                                                 // 289
                                                                                                                      //
    return excludeFiles;                                                                                              // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.filterArchFiles = function () {                                                        // 24
    function filterArchFiles(inputFiles, arch) {                                                                      // 24
      check(arch, String);                                                                                            // 292
                                                                                                                      //
      var archFiles = inputFiles.filter(function (inputFile, index) {                                                 // 294
        if (inputFile.isConfig()) return false;                                                                       // 295
                                                                                                                      //
        return inputFile.getArch() === arch;                                                                          // 297
      });                                                                                                             // 298
                                                                                                                      //
      // Include only typings that current arch needs,                                                                // 300
      // typings/main is for the server only and                                                                      // 301
      // typings/browser - for the client.                                                                            // 302
      var exclude = arch.startsWith('web') ? exlWebRegExp : exlMainRegExp;                                            // 303
                                                                                                                      //
      archFiles = archFiles.filter(function (inputFile) {                                                             // 306
        var path = inputFile.getPathInPackage();                                                                      // 307
        return !exclude.test('/' + path);                                                                             // 308
      });                                                                                                             // 309
                                                                                                                      //
      return archFiles;                                                                                               // 311
    }                                                                                                                 // 312
                                                                                                                      //
    return filterArchFiles;                                                                                           // 24
  }();                                                                                                                // 24
                                                                                                                      //
  TypeScriptCompiler.prototype.getTypings = function () {                                                             // 24
    function getTypings(filePaths) {                                                                                  // 24
      check(filePaths, Array);                                                                                        // 315
                                                                                                                      //
      return filePaths.filter(function (filePath) {                                                                   // 317
        return TypeScript.isDeclarationFile(filePath);                                                                // 318
      });                                                                                                             // 319
    }                                                                                                                 // 320
                                                                                                                      //
    return getTypings;                                                                                                // 24
  }();                                                                                                                // 24
                                                                                                                      //
  return TypeScriptCompiler;                                                                                          // 24
}();                                                                                                                  // 24
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"typescript.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var meteorTS = Npm.require('meteor-typescript');                                                                      // 1
                                                                                                                      //
TypeScript = {                                                                                                        // 3
  validateOptions: function () {                                                                                      // 4
    function validateOptions(options) {                                                                               // 3
      if (!options) return;                                                                                           // 5
                                                                                                                      //
      meteorTS.validateAndConvertOptions(options);                                                                    // 7
    }                                                                                                                 // 8
                                                                                                                      //
    return validateOptions;                                                                                           // 3
  }(),                                                                                                                // 3
                                                                                                                      //
                                                                                                                      //
  // Extra options are the same compiler options                                                                      // 10
  // but passed in the compiler constructor.                                                                          // 11
  validateExtraOptions: function () {                                                                                 // 12
    function validateExtraOptions(options) {                                                                          // 3
      if (!options) return;                                                                                           // 13
                                                                                                                      //
      meteorTS.validateAndConvertOptions({                                                                            // 15
        compilerOptions: options                                                                                      // 16
      });                                                                                                             // 15
    }                                                                                                                 // 18
                                                                                                                      //
    return validateExtraOptions;                                                                                      // 3
  }(),                                                                                                                // 3
                                                                                                                      //
                                                                                                                      //
  getDefaultOptions: meteorTS.getDefaultOptions,                                                                      // 20
                                                                                                                      //
  compile: function () {                                                                                              // 22
    function compile(source, options) {                                                                               // 3
      options = options || meteorTS.getDefaultOptions();                                                              // 23
      return meteorTS.compile(source, options);                                                                       // 24
    }                                                                                                                 // 25
                                                                                                                      //
    return compile;                                                                                                   // 3
  }(),                                                                                                                // 3
  setCacheDir: function () {                                                                                          // 27
    function setCacheDir(cacheDir) {                                                                                  // 3
      meteorTS.setCacheDir(cacheDir);                                                                                 // 28
    }                                                                                                                 // 29
                                                                                                                      //
    return setCacheDir;                                                                                               // 3
  }(),                                                                                                                // 3
  isDeclarationFile: function () {                                                                                    // 31
    function isDeclarationFile(filePath) {                                                                            // 3
      return filePath.match(/^.*\.d\.ts$/);                                                                           // 32
    }                                                                                                                 // 33
                                                                                                                      //
    return isDeclarationFile;                                                                                         // 3
  }(),                                                                                                                // 3
  removeTsExt: function () {                                                                                          // 35
    function removeTsExt(path) {                                                                                      // 3
      return path && path.replace(/(\.tsx|\.ts)$/g, '');                                                              // 36
    }                                                                                                                 // 37
                                                                                                                      //
    return removeTsExt;                                                                                               // 3
  }()                                                                                                                 // 3
};                                                                                                                    // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/barbatus:typescript-compiler/logger.js");
require("./node_modules/meteor/barbatus:typescript-compiler/file-mixin.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript-compiler.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['barbatus:typescript-compiler'] = {}, {
  TypeScript: TypeScript,
  TypeScriptCompiler: TypeScriptCompiler
});

})();

//# sourceMappingURL=barbatus_typescript-compiler.js.map
